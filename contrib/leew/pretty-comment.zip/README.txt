"pretty-comment" is an experimental noweb filter that lets code chunk
comments be typeset by LaTeX rather than just printed verbatim like
the rest of the code.  It currently only works for "short" comments that
begin with a single or multi-character symbol and end with a newline.
And, let's face it, "long" multi-line comments are unnecessary in a
literate program, so it probably will never deal with those.

Use it noweave's "-filter" option:

	noweave -filter pretty-comment < pgm.nw >pgm.tex

By default it assumes that comments are introduced by the C++/Java
"//" symbol, but accepts one or two command-line arguments to deal
with languages that have different comment symbol.  The first is the
string to recognize as the start-of-comment symbol.  For example:

	noweave -filter 'pretty-comment \#' < pgm.nw >pgm.tex

could be used to typeset comments in a shell script (or in any of the
myriad scripting languages that use '#' as a comment starter).  The
backslash is necessary in the Bourne and Bourne Again shells; other
command interpreters (such as Windows' "cmd") may not need it.

In this case, the comment delimiter will be typeset in typewriter font
with the rest of the code.  If you want it typeset differently, you
can specify a second argument to the filter.  For example,

	noweave -filter 'pretty-comment \# \\mbox{\\rm\\#}' < pgm.nw >pgm.tex

will typeset the #-sign in roman Computer Modern like the rest of the
comment (and the text chunks).  Again, the backslash escapes are needed
for "sh" and "bash", but things may work differently elsewhere.
Invoking "pretty-comment" without any arguments is equivalent to:

	noweave -filter 'pretty-comment // /\\negthinspace\\negthinspace/' < pgm.nw >pgm.tex

The "pretty-comment" filter is implemented in Snobol.  I make no
apologies for this.  Icon is interesting, Python is cool, and Perl is
ubiquitous, but Snobol is fun.  Like these other languages, Snobol is
available for all popular platforms, at

	http://www.snobol4.org/csnobol4/curr/

If you are using Windows, you might want to rename the filter to
"pretty-comment.sno".

I won't object if anyone wants to rewrite it in another language, but
I will maintain (and use) only this version.

Lee Wittenberg
leew@alumni.stanford.edu
